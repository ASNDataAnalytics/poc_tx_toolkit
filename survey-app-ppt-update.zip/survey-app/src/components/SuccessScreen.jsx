// src/components/SuccessScreen.jsx
export default function SuccessScreen({ onDownloadPdf, onDownloadPpt, onReset }) {
  return (
    <div className="success-screen">
      <div className="success-icon">✓</div>
      <h2 className="success-title">Survey Complete</h2>
      <p className="success-desc">
        Your responses are ready to export. Choose a format below.
        Nothing has been transmitted — all data stays in this browser.
      </p>

      <div className="download-options">
        <button className="download-card" onClick={onDownloadPdf}>
          <div className="download-card-icon">⬇</div>
          <div className="download-card-body">
            <div className="download-card-title">PDF Report</div>
            <div className="download-card-desc">Formatted report — ideal for sharing or printing</div>
          </div>
          <div className="download-card-ext">.pdf</div>
        </button>

        <button className="download-card" onClick={onDownloadPpt}>
          <div className="download-card-icon">⬇</div>
          <div className="download-card-body">
            <div className="download-card-title">PowerPoint Deck</div>
            <div className="download-card-desc">Editable slide deck — ideal for presentations</div>
          </div>
          <div className="download-card-ext">.pptx</div>
        </button>
      </div>

      <button className="btn btn-ghost" onClick={onReset}>
        ↺ Start a new survey
      </button>
    </div>
  )
}
